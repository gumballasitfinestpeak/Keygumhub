export enum RevealStatus {
  IDLE = 'IDLE',
  COUNTING = 'COUNTING',
  REVEALED = 'REVEALED',
}

export interface KeyConfig {
  value: string;
  expiration: string;
  label: string;
}
