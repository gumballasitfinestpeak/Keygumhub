import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Copy, Check, Lock, Unlock, KeyRound } from 'lucide-react';
import { RevealStatus, KeyConfig } from '../types';

interface KeyRevealCardProps {
  status: RevealStatus;
  onStartReveal: () => void;
  onReset: () => void;
  keyData: KeyConfig;
}

const KeyRevealCard: React.FC<KeyRevealCardProps> = ({ status, onStartReveal, onReset, keyData }) => {
  const [countdown, setCountdown] = useState(5);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    let timer: number;
    if (status === RevealStatus.COUNTING && countdown > 0) {
      timer = window.setTimeout(() => setCountdown(c => c - 1), 1000);
    }
    return () => clearTimeout(timer);
  }, [status, countdown]);

  const handleCopy = () => {
    navigator.clipboard.writeText(keyData.value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="relative z-10 w-full max-w-lg mx-auto p-6">
      <motion.div
        layout
        className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl shadow-2xl overflow-hidden"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent opacity-50" />
        
        <div className="p-8 flex flex-col items-center text-center min-h-[300px] justify-center">
          <AnimatePresence mode="wait">
            
            {/* IDLE STATE */}
            {status === RevealStatus.IDLE && (
              <motion.div
                key="idle"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="flex flex-col items-center gap-6"
              >
                <div className="p-4 bg-blue-500/20 rounded-full border border-blue-400/30 shadow-[0_0_30px_rgba(59,130,246,0.2)]">
                  <Lock className="w-10 h-10 text-cyan-200" />
                </div>
                <div>
                  <h2 className="text-3xl font-display font-bold text-white mb-2">Secure Key Reveal</h2>
                  <p className="text-blue-200/80">Initiate the sequence to decrypt your access token.</p>
                </div>
                <button
                  onClick={onStartReveal}
                  className="group relative px-8 py-3 bg-cyan-500 hover:bg-cyan-400 text-slate-900 font-bold rounded-full transition-all shadow-[0_0_20px_rgba(6,182,212,0.3)] hover:shadow-[0_0_30px_rgba(6,182,212,0.5)] active:scale-95"
                >
                  <span className="relative z-10 flex items-center gap-2">
                    Reveal Key <KeyRound className="w-4 h-4" />
                  </span>
                </button>
              </motion.div>
            )}

            {/* COUNTING STATE */}
            {status === RevealStatus.COUNTING && (
              <motion.div
                key="counting"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.5, filter: "blur(10px)" }}
                className="flex flex-col items-center justify-center"
              >
                <div className="relative">
                  <svg className="w-40 h-40 -rotate-90">
                    <circle
                      cx="80"
                      cy="80"
                      r="70"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="transparent"
                      className="text-blue-900/40"
                    />
                    <motion.circle
                      cx="80"
                      cy="80"
                      r="70"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="transparent"
                      className="text-cyan-400"
                      strokeDasharray="440"
                      strokeDashoffset="0"
                      initial={{ strokeDashoffset: 0 }}
                      animate={{ strokeDashoffset: 440 }}
                      transition={{ duration: 5, ease: "linear" }}
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <motion.span
                      key={countdown}
                      initial={{ scale: 1.5, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.5, opacity: 0 }}
                      className="text-6xl font-display font-bold text-white tabular-nums"
                    >
                      {countdown}
                    </motion.span>
                  </div>
                </div>
                <p className="mt-6 text-cyan-200 font-medium tracking-widest uppercase text-sm animate-pulse">
                  Decrypting...
                </p>
              </motion.div>
            )}

            {/* REVEALED STATE */}
            {status === RevealStatus.REVEALED && (
              <motion.div
                key="revealed"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ type: "spring", bounce: 0.5 }}
                className="w-full flex flex-col items-center gap-6"
              >
                 <div className="p-4 bg-green-500/20 rounded-full border border-green-400/30 shadow-[0_0_30px_rgba(34,197,94,0.3)]">
                  <Unlock className="w-10 h-10 text-green-200" />
                </div>
                
                <div className="w-full">
                  <h3 className="text-sm uppercase tracking-wider text-blue-300 mb-2 font-semibold">Access Key</h3>
                  <div className="relative group">
                    <div className="w-full bg-slate-900/50 border border-blue-500/30 rounded-xl p-4 pr-12 font-mono text-lg text-cyan-300 break-all shadow-inner">
                      {keyData.value}
                    </div>
                    <button
                      onClick={handleCopy}
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-blue-400 hover:text-white transition-colors rounded-lg hover:bg-white/10"
                      title="Copy to clipboard"
                    >
                      {copied ? <Check className="w-5 h-5 text-green-400" /> : <Copy className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-2 px-4 py-2 bg-white/5 rounded-lg border border-white/10">
                  <span className="text-blue-200 text-sm">Expiration:</span>
                  <span className="text-green-300 font-bold font-mono tracking-wide">{keyData.expiration}</span>
                </div>

                <button
                  onClick={onReset}
                  className="mt-4 text-sm text-blue-300/60 hover:text-blue-200 underline decoration-blue-500/30 hover:decoration-blue-400 transition-all"
                >
                  Run sequence again
                </button>
              </motion.div>
            )}

          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
};

export default KeyRevealCard;
