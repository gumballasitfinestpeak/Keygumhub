import React, { useState, useEffect } from 'react';
import OceanBackground from './components/OceanBackground';
import KeyRevealCard from './components/KeyRevealCard';
import { RevealStatus, KeyConfig } from './types';

// Configuration for the key being revealed
const KEY_DATA: KeyConfig = {
  value: "GumHubIsStillOnBeta",
  expiration: "NONE",
  label: "Beta Access Key"
};

const App: React.FC = () => {
  const [status, setStatus] = useState<RevealStatus>(RevealStatus.IDLE);

  // Handle the countdown logic completion
  useEffect(() => {
    let timeout: number;
    if (status === RevealStatus.COUNTING) {
      // 5 seconds matches the visual countdown in KeyRevealCard
      timeout = window.setTimeout(() => {
        setStatus(RevealStatus.REVEALED);
      }, 5000);
    }
    return () => clearTimeout(timeout);
  }, [status]);

  const handleStartReveal = () => {
    setStatus(RevealStatus.COUNTING);
  };

  const handleReset = () => {
    setStatus(RevealStatus.IDLE);
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col items-center justify-center p-4">
      <OceanBackground />
      
      <main className="w-full flex flex-col items-center z-10 gap-8">
        <header className="text-center space-y-2">
          <h1 className="text-4xl md:text-5xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-200 to-blue-200 drop-shadow-lg">
            Gum Hub
          </h1>
          <div className="h-1 w-24 mx-auto bg-gradient-to-r from-transparent via-cyan-500 to-transparent rounded-full opacity-70" />
        </header>
        
        <KeyRevealCard 
          status={status} 
          onStartReveal={handleStartReveal} 
          onReset={handleReset}
          keyData={KEY_DATA}
        />

        <footer className="absolute bottom-4 text-blue-300/40 text-xs text-center w-full">
          &copy; {new Date().getFullYear()} Ocean Reveal System. All rights reserved.
        </footer>
      </main>
    </div>
  );
};

export default App;
